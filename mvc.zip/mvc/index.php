<?php
require "application/lib/Dev.php";

use application\core\Router;

//функция автоматически подгружает все используемые use
spl_autoload_register(function($class){
    $path = str_replace("\\","/",$class.".php");//замена \ на / для правильной работы директории
    if(file_exists($path)){
       // echo $path."<br>";
        require $path;
    }
}
);
session_start();
$router = new Router; 
$router->run();
